# HIT STORE Panel - Pterodactyl Docker Setup

Panel ini berbasis [Pterodactyl Panel](https://pterodactyl.io) dan siap dijalankan menggunakan `docker-compose`.

## Cara Pakai

1. Clone repo ini:
```bash
git clone https://github.com/username/hitstore-panel.git
cd hitstore-panel
```

2. Jalankan Docker:
```bash
docker-compose up -d
```

3. Buat user admin:
```bash
docker-compose run --rm panel php artisan p:user:make
```

## Notes
- Pastikan kamu sudah punya VPS (Ubuntu 20.04 / 22.04)
- Port 80 & 443 harus terbuka
- Bisa dikombinasikan dengan reverse proxy (Nginx / Caddy)

---

Panel ini disiapkan untuk keperluan belajar & eksperimen HIT STORE.